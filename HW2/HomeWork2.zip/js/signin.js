
// // required field
// function validate_required(field,alerttxt)
// {
// with (field)
// {
// if (value==null||value=="")
//   {alert(alerttxt);return false}
// else {return true}
// }
// }

// function validate_form(thisform)
// {
// with (thisform)
//   {
//   if (validate_required(firstname,"Firstname must be filled out!")==false)
//     {email.focus();return false}
//   }
//   if (validate_required(lastname,"lastname must be filled out!")==false)
//     {email.focus();return false}
//   }
//   if (validate_required(addressline1,"Address line 1 must be filled out!")==false)
//     {email.focus();return false}
//   }

//   if (validate_required(email,"Email must be filled out!")==false)
//     {email.focus();return false}
//   }

//   if (validate_required(phone,"Phone must be filled out!")==false)
//     {email.focus();return false}
//   }
//   if (validate_required(comment,"Comment must be filled out!")==false)
//     {email.focus();return false}
//   }
  

// }
